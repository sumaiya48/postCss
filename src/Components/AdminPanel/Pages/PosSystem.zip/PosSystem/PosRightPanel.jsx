import React, { useEffect } from "react";
import {
  Page,
  Text,
  View,
  Document,
  StyleSheet,
  Image,
  pdf,
} from "@react-pdf/renderer";
import { saveAs } from "file-saver";

const logo = "/logo.png"; // or Base64 string

// Define styles and InvoiceDocument (as before)...

const InvoiceGenerator = ({
  orderData,
  selectedCustomer,
  selectedItems,
  grossTotal,
  couponDiscount,
  newOrderId,
  triggerGenerate,
  onGenerated,
}) => {
  useEffect(() => {
    const generatePdf = async () => {
      try {
        const doc = (
          <InvoiceDocument
            orderData={orderData}
            selectedCustomer={selectedCustomer}
            selectedItems={selectedItems}
            grossTotal={grossTotal}
            couponDiscount={couponDiscount}
            newOrderId={newOrderId}
          />
        );

        const blob = await pdf(doc).toBlob(); // 👈 This needs polyfills in some bundlers
        saveAs(blob, `Invoice-ORD-${newOrderId}.pdf`);
        onGenerated();
      } catch (err) {
        console.error("PDF generation error:", err);
      }
    };

    if (triggerGenerate) {
      generatePdf(); // will only work if `Buffer` is polyfilled or this runs in supported environments
    }
  }, [triggerGenerate]);

  return null;
};

export default InvoiceGenerator;
