// InvoiceGenerator.jsx
import React from "react";
import {
  PDFViewer,
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  Font,
} from "@react-pdf/renderer";

// Custom styles
const styles = StyleSheet.create({
  page: {
    padding: 30,
    fontSize: 10,
    fontFamily: "Helvetica",
  },
  header: {
    marginBottom: 20,
    borderBottom: "1 solid #000",
    paddingBottom: 10,
  },
  section: {
    marginVertical: 10,
  },
  row: {
    flexDirection: "row",
    borderBottom: "1 solid #ccc",
    paddingVertical: 4,
  },
  cell: {
    flex: 1,
    paddingRight: 5,
  },
  bold: {
    fontWeight: "bold",
  },
  totalRow: {
    flexDirection: "row",
    justifyContent: "flex-end",
    marginTop: 10,
  },
  totalLabel: {
    fontWeight: "bold",
    marginRight: 10,
  },
  totalValue: {
    fontWeight: "bold",
  },
});

const InvoicePDF = ({
  orderData,
  selectedCustomer,
  selectedItems,
  grossTotal,
  couponDiscount,
  newOrderId,
}) => (
  <Document>
    <Page size="A4" style={styles.page}>
      <View style={styles.header}>
        <Text style={{ fontSize: 16, fontWeight: "bold" }}>Invoice</Text>
        <Text>Order ID: #{newOrderId}</Text>
        <Text>
          Customer: {selectedCustomer.name} ({selectedCustomer.phone})
        </Text>
        <Text>Date: {new Date().toLocaleDateString()}</Text>
      </View>

      <View style={styles.section}>
        <Text style={{ marginBottom: 5, fontWeight: "bold" }}>
          Order Items:
        </Text>
        {selectedItems.map((item, index) => (
          <View key={index} style={styles.row}>
            <Text style={styles.cell}>{item.name}</Text>
            <Text style={styles.cell}>{item.quantity} pcs</Text>
            <Text style={styles.cell}>{item.customUnitPrice} Tk</Text>
            <Text style={styles.cell}>
              {(item.customUnitPrice * item.quantity).toFixed(2)} Tk
            </Text>
          </View>
        ))}
      </View>

      <View style={styles.totalRow}>
        <Text style={styles.totalLabel}>Sub Total:</Text>
        <Text>{(grossTotal + couponDiscount).toFixed(2)} Tk</Text>
      </View>
      <View style={styles.totalRow}>
        <Text style={styles.totalLabel}>Discount:</Text>
        <Text>{couponDiscount.toFixed(2)} Tk</Text>
      </View>
      <View style={styles.totalRow}>
        <Text style={styles.totalLabel}>Total:</Text>
        <Text style={styles.totalValue}>{grossTotal.toFixed(2)} Tk</Text>
      </View>
    </Page>
  </Document>
);

const InvoiceGenerator = ({
  orderData,
  selectedCustomer,
  selectedItems,
  grossTotal,
  couponDiscount,
  newOrderId,
  triggerGenerate,
  onGenerated,
}) => {
  React.useEffect(() => {
    if (triggerGenerate) {
      setTimeout(() => {
        if (onGenerated) onGenerated(); // reset trigger in parent
      }, 1000); // Allow viewer to render
    }
  }, [triggerGenerate, onGenerated]);

  if (!triggerGenerate || !orderData || !selectedItems || !selectedCustomer)
    return null;

  return (
    <div className="fixed top-0 left-0 w-screen h-screen bg-white z-[9999]">
      <PDFViewer width="100%" height="100%">
        <InvoicePDF
          orderData={orderData}
          selectedCustomer={selectedCustomer}
          selectedItems={selectedItems}
          grossTotal={grossTotal}
          couponDiscount={couponDiscount}
          newOrderId={newOrderId}
        />
      </PDFViewer>
    </div>
  );
};

export default InvoiceGenerator;
